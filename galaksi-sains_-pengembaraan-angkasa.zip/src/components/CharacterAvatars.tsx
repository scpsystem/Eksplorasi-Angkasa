import React from 'react';
import { CharacterGender } from '../types/game';

interface CharacterAvatarProps {
  gender: CharacterGender;
  size?: number;
  className?: string;
  isAnimated?: boolean;
  action?: 'idle' | 'running' | 'jumping' | 'celebrate';
}

export const CharacterAvatar: React.FC<CharacterAvatarProps> = ({
  gender,
  size = 64,
  className = '',
  isAnimated = false,
  action = 'idle'
}) => {
  const isMale = gender === 'lelaki';
  const suitColor = isMale ? '#0284C7' : '#D946EF'; // Cyan/Blue for Aiman, Fuchsia/Magenta for Melia
  const visorColor = '#38BDF8';
  const visorReflection = '#BAE6FD';

  // Animation classes
  let animClass = '';
  if (isAnimated) {
    if (action === 'running') animClass = 'animate-bounce';
    else if (action === 'jumping') animClass = '-translate-y-4 transition-transform duration-200';
    else if (action === 'celebrate') animClass = 'scale-110 rotate-3 transition-transform duration-300';
    else animClass = 'animate-pulse';
  }

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 ${animClass} ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-md"
      >
        {/* Glow behind character */}
        <circle cx="50" cy="50" r="44" fill={suitColor} fillOpacity="0.15" />

        {/* Jetpack on back */}
        <rect x="22" y="44" width="12" height="28" rx="4" fill="#334155" />
        <rect x="66" y="44" width="12" height="28" rx="4" fill="#334155" />
        {/* Jetpack nozzle & thruster light */}
        <path d="M25 72 L23 80 L33 80 L31 72 Z" fill="#64748B" />
        <path d="M69 72 L67 80 L77 80 L75 72 Z" fill="#64748B" />
        {action === 'running' || action === 'jumping' ? (
          <>
            <polygon points="24,80 32,80 28,90" fill="#38BDF8" className="animate-ping" />
            <polygon points="68,80 76,80 72,90" fill="#38BDF8" className="animate-ping" />
          </>
        ) : null}

        {/* Space Suit Body */}
        <rect x="32" y="42" width="36" height="34" rx="8" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2" />

        {/* Chest Accent Badge */}
        <rect x="38" y="46" width="24" height="12" rx="3" fill={suitColor} />
        <circle cx="44" cy="52" r="2.5" fill="#FFFFFF" />
        <line x1="50" y1="52" x2="58" y2="52" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />

        {/* Arms */}
        <path
          d={
            action === 'celebrate'
              ? 'M32 46 Q20 30 22 24'
              : action === 'running'
              ? 'M32 50 Q22 55 24 64'
              : 'M32 48 Q24 56 26 64'
          }
          stroke="#F8FAFC"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <path
          d={
            action === 'celebrate'
              ? 'M68 46 Q80 30 78 24'
              : action === 'running'
              ? 'M68 50 Q78 45 76 38'
              : 'M68 48 Q76 56 74 64'
          }
          stroke="#F8FAFC"
          strokeWidth="6"
          strokeLinecap="round"
        />

        {/* Gloves */}
        <circle cx={action === 'celebrate' ? 22 : 26} cy={action === 'celebrate' ? 24 : 64} r="4" fill={suitColor} />
        <circle cx={action === 'celebrate' ? 78 : (action === 'running' ? 76 : 74)} cy={action === 'celebrate' ? 24 : (action === 'running' ? 38 : 64)} r="4" fill={suitColor} />

        {/* Legs & Boots */}
        <path d="M40 76 L38 88" stroke="#E2E8F0" strokeWidth="6" strokeLinecap="round" />
        <path d="M60 76 L62 88" stroke="#E2E8F0" strokeWidth="6" strokeLinecap="round" />
        <rect x="33" y="86" width="12" height="6" rx="3" fill="#1E293B" />
        <rect x="57" y="86" width="12" height="6" rx="3" fill="#1E293B" />

        {/* Space Helmet Dome */}
        <circle cx="50" cy="27" r="21" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2.5" />
        {/* Helmet Visor */}
        <path
          d="M34 27 C34 18 41 12 50 12 C59 12 66 18 66 27 C66 35 59 40 50 40 C41 40 34 35 34 27 Z"
          fill="#0F172A"
        />
        <path
          d="M36 26 C36 19 42 14 50 14 C58 14 64 19 64 26 C64 33 58 38 50 38 C42 38 36 33 36 26 Z"
          fill={visorColor}
          fillOpacity="0.85"
        />
        {/* Visor Specular Reflection */}
        <path
          d="M40 18 C43 16 47 15 52 15 C54 15 56 16 58 17"
          stroke={visorReflection}
          strokeWidth="2.5"
          strokeLinecap="round"
        />

        {/* Face inside (cute cartoon eyes & smile visible through transparent visor) */}
        {isMale ? (
          <>
            {/* Aiman's neat hair peek */}
            <path d="M43 19 Q50 16 56 19" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" />
            <circle cx="45" cy="27" r="2.2" fill="#FFFFFF" />
            <circle cx="55" cy="27" r="2.2" fill="#FFFFFF" />
            <path d="M47 32 Q50 34 53 32" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          </>
        ) : (
          <>
            {/* Melia's purple tudung / inner hair aesthetic */}
            <path d="M40 22 Q50 17 60 22" stroke="#D946EF" strokeWidth="3" strokeLinecap="round" />
            <circle cx="45" cy="27" r="2.2" fill="#FFFFFF" />
            <circle cx="55" cy="27" r="2.2" fill="#FFFFFF" />
            {/* Melia's lashes */}
            <path d="M43 25 L41 24" stroke="#FFFFFF" strokeWidth="1" />
            <path d="M57 25 L59 24" stroke="#FFFFFF" strokeWidth="1" />
            <path d="M47 32 Q50 35 53 32" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          </>
        )}

        {/* Antenna */}
        <line x1="50" y1="6" x2="50" y2="1" stroke="#94A3B8" strokeWidth="2" />
        <circle cx="50" cy="1" r="2" fill={suitColor} />
      </svg>
    </div>
  );
};
