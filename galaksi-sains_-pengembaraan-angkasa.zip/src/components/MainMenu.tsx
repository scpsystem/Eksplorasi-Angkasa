import React, { useState } from 'react';
import { CharacterGender, GameProgress } from '../types/game';
import { CHARACTER_PROFILES } from '../data/learningContent';
import { CharacterAvatar } from './CharacterAvatars';
import { soundEffects } from '../utils/audio';
import {
  Rocket,
  Moon,
  Sparkles,
  Star,
  Play,
  RotateCcw,
  BookOpen,
  Volume2,
  VolumeX,
  Info,
  CheckCircle2,
  ChevronRight,
  Telescope
} from 'lucide-react';

interface MainMenuProps {
  progress: GameProgress;
  onSelectCharacter: (gender: CharacterGender) => void;
  onStartActivity: (activity: 'lunar_rush' | 'star_quest' | 'galaxy_explorer') => void;
  onResetGame: () => void;
  onToggleAudio: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  progress,
  onSelectCharacter,
  onStartActivity,
  onResetGame,
  onToggleAudio
}) => {
  const [showInstructions, setShowInstructions] = useState<boolean>(false);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  const totalStarsCount =
    (progress.starsEarned.lunarRush ? 1 : 0) +
    (progress.starsEarned.starQuest ? 1 : 0) +
    (progress.starsEarned.galaxyExplorer ? 1 : 0);

  const handleLaunchFirstAvailable = () => {
    soundEffects.playClick();
    if (!progress.starsEarned.lunarRush) {
      onStartActivity('lunar_rush');
    } else if (!progress.starsEarned.starQuest) {
      onStartActivity('star_quest');
    } else {
      onStartActivity('galaxy_explorer');
    }
  };

  return (
    <div className="relative w-full min-h-[92vh] flex flex-col items-center justify-between p-4 sm:p-8 bg-slate-950 text-white select-none overflow-hidden">
      {/* Background Cosmic Starfield & Nebula Canvas */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-1/4 w-96 h-96 rounded-full bg-sky-600/10 blur-3xl animate-pulse" />
        <div className="absolute bottom-10 right-1/4 w-96 h-96 rounded-full bg-purple-600/10 blur-3xl" />
        <div className="absolute top-1/2 right-10 w-64 h-64 rounded-full bg-amber-500/10 blur-3xl" />
        {/* Subtle grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      </div>

      {/* Top Bar with Score, Stars, Instructions & Audio Toggle */}
      <header className="relative w-full max-w-5xl flex items-center justify-between gap-4 pb-4 border-b border-slate-800/80 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-400/30">
            <Rocket className="w-4 h-4" />
          </div>
          <span className="text-sm font-bold tracking-wider text-slate-200">
            KSSR SAINS TAHUN 5 · UNIT 9
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Total Score Badge */}
          <div className="flex items-center gap-2 bg-slate-900/90 px-3.5 py-1.5 rounded-xl border border-slate-700 shadow-sm">
            <span className="text-xs text-slate-400">Markah:</span>
            <span className="text-sm sm:text-base font-extrabold text-amber-300 tabular-nums">
              {progress.totalScore}
            </span>
          </div>

          {/* Stars Tally Badge */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 px-3.5 py-1.5 rounded-xl border border-slate-700 shadow-sm">
            <div className="flex items-center gap-0.5">
              {[0, 1, 2].map(idx => (
                <Star
                  key={idx}
                  className={`w-4 h-4 ${
                    idx < totalStarsCount
                      ? 'text-amber-400 fill-amber-400'
                      : 'text-slate-600'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs font-bold text-amber-300 ml-1">
              {totalStarsCount}/3 Bintang
            </span>
          </div>

          {/* Guide / Panduan Button */}
          <button
            onClick={() => {
              soundEffects.playClick();
              setShowInstructions(true);
            }}
            type="button"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 transition-colors"
            title="Panduan Permainan & DSKP"
          >
            <BookOpen className="w-4 h-4" />
          </button>

          {/* Audio Toggle */}
          <button
            onClick={() => {
              soundEffects.playClick();
              onToggleAudio();
            }}
            type="button"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title={progress.audioEnabled ? 'Bisukan Bunyi' : 'Buka Bunyi'}
          >
            {progress.audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Hero Section: Game Title & Subtitle */}
      <div className="relative text-center my-6 z-10 max-w-3xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-400/20 text-xs font-semibold text-sky-300">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Fasa Bulan dan Buruj · Interaktif & Menyeronokkan</span>
        </div>

        <h1 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-sky-300 via-indigo-200 to-amber-300 drop-shadow-sm">
          GALAKSI SAINS
        </h1>
        <h2 className="text-lg sm:text-2xl font-extrabold tracking-widest text-sky-400 uppercase">
          PENGEMBARAAN ANGKASA
        </h2>
        <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto leading-relaxed">
          Kembara merentasi permukaan Bulan, teroka rahsia 4 buruj purba, dan takluki teras galaksi dengan ilmu sains anda!
        </p>

        {/* Big Launch Button */}
        <div className="pt-2">
          <button
            onClick={handleLaunchFirstAvailable}
            type="button"
            className="inline-flex items-center gap-3 px-8 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-400 hover:to-indigo-400 text-slate-950 font-black text-base sm:text-lg tracking-wide shadow-xl shadow-sky-500/25 active:scale-95 transition-all cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            <span>MULA PERMAINAN</span>
          </button>
        </div>
      </div>

      {/* Character Selector Section */}
      <div className="relative w-full max-w-xl bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 z-10 space-y-3 shadow-xl backdrop-blur-xs">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-sky-300 uppercase tracking-wider">
            Pilih Watak Pengembara Anda:
          </span>
          <span className="text-xs text-slate-400">
            {progress.character === 'lelaki' ? 'Aiman (Kapten)' : 'Melia (Pakar Astronomi)'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {CHARACTER_PROFILES.map(profile => {
            const isSelected = progress.character === profile.id;
            return (
              <button
                key={profile.id}
                type="button"
                onClick={() => {
                  soundEffects.playClick();
                  onSelectCharacter(profile.id);
                }}
                className={`p-3 rounded-xl border flex items-center gap-3 text-left transition-all ${
                  isSelected
                    ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-400/50 shadow-md'
                    : 'bg-slate-800/60 border-slate-700/80 hover:bg-slate-800 text-slate-300'
                }`}
              >
                <CharacterAvatar
                  gender={profile.id}
                  size={48}
                  isAnimated={isSelected}
                  action={isSelected ? 'running' : 'idle'}
                />
                <div>
                  <h4 className="text-sm font-bold text-white">{profile.name}</h4>
                  <p className="text-[11px] text-slate-300 leading-tight line-clamp-1">{profile.title}</p>
                  <span className={`text-[10px] font-semibold mt-1 inline-block ${isSelected ? 'text-sky-300' : 'text-slate-400'}`}>
                    {isSelected ? '✓ Dipilih' : 'Klik untuk pilih'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3 Main Activity Game Cards */}
      <div className="relative w-full max-w-5xl grid grid-cols-1 md:grid-cols-3 gap-4 my-6 z-10">
        {/* Card 1: Lunar Rush */}
        <div
          onClick={() => {
            soundEffects.playClick();
            onStartActivity('lunar_rush');
          }}
          className={`group relative p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
            progress.starsEarned.lunarRush
              ? 'bg-gradient-to-b from-sky-950/60 to-slate-900/90 border-emerald-500/50 shadow-lg'
              : 'bg-gradient-to-b from-slate-900 to-slate-950 hover:from-sky-950/40 hover:to-slate-900 border-slate-800 hover:border-sky-500/50'
          }`}
        >
          {progress.starsEarned.lunarRush && (
            <div className="absolute top-3 right-3 flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Selesai (+1 ⭐)</span>
            </div>
          )}

          <div>
            <div className="w-12 h-12 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-400/30 mb-3 group-hover:scale-110 transition-transform">
              <Moon className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-sky-400 uppercase tracking-widest block">
              Aktiviti 1 · Fasa Bulan
            </span>
            <h3 className="text-lg font-extrabold text-white mt-1 group-hover:text-sky-300 transition-colors">
              Misi Bulan – Lunar Rush
            </h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Kawal angkasawan berlari di atas permukaan Bulan, kumpul kristal, dan jawab 7 checkpoint soalan tentang Fasa Bulan!
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">7 Checkpoint · Temple Run</span>
            <span className="text-xs font-bold text-sky-400 group-hover:translate-x-1 transition-transform flex items-center">
              Main Misi <ChevronRight className="w-4 h-4 ml-0.5" />
            </span>
          </div>
        </div>

        {/* Card 2: Star Quest */}
        <div
          onClick={() => {
            soundEffects.playClick();
            onStartActivity('star_quest');
          }}
          className={`group relative p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
            progress.starsEarned.starQuest
              ? 'bg-gradient-to-b from-purple-950/60 to-slate-900/90 border-emerald-500/50 shadow-lg'
              : 'bg-gradient-to-b from-slate-900 to-slate-950 hover:from-purple-950/40 hover:to-slate-900 border-slate-800 hover:border-purple-500/50'
          }`}
        >
          {progress.starsEarned.starQuest && (
            <div className="absolute top-3 right-3 flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Selesai (+1 ⭐)</span>
            </div>
          )}

          <div>
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-400/30 mb-3 group-hover:scale-110 transition-transform">
              <Telescope className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-purple-400 uppercase tracking-widest block">
              Aktiviti 2 · Buruj
            </span>
            <h3 className="text-lg font-extrabold text-white mt-1 group-hover:text-purple-300 transition-colors">
              Misi Bintang – Star Quest
            </h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Teroka 7 bintang bersinar di angkasa lepas untuk membongkar rahsia corak buruj Biduk, Belantik, Pari, dan Skorpio!
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">7 Bintang · Penerokaan Angkasa</span>
            <span className="text-xs font-bold text-purple-400 group-hover:translate-x-1 transition-transform flex items-center">
              Main Misi <ChevronRight className="w-4 h-4 ml-0.5" />
            </span>
          </div>
        </div>

        {/* Card 3: Galaxy Explorer */}
        <div
          onClick={() => {
            soundEffects.playClick();
            onStartActivity('galaxy_explorer');
          }}
          className={`group relative p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
            progress.starsEarned.galaxyExplorer
              ? 'bg-gradient-to-b from-amber-950/60 to-slate-900/90 border-emerald-500/50 shadow-lg'
              : 'bg-gradient-to-b from-slate-900 to-slate-950 hover:from-amber-950/40 hover:to-slate-900 border-slate-800 hover:border-amber-500/50'
          }`}
        >
          {progress.starsEarned.galaxyExplorer && (
            <div className="absolute top-3 right-3 flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Selesai (+1 ⭐)</span>
            </div>
          )}

          <div>
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/30 mb-3 group-hover:scale-110 transition-transform">
              <Rocket className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest block">
              Aktiviti 3 · Peta Galaksi Interaktif
            </span>
            <h3 className="text-lg font-extrabold text-white mt-1 group-hover:text-amber-300 transition-colors">
              Eksplorasi Angkasa – Galaxy Explorer
            </h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Peta pengembaraan berurutan dari Stesen Angkasa sehingga ke Pusat Galaksi menggabungkan Fasa Bulan dan Buruj!
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">7 Zon Kosmik · Laluan Peta</span>
            <span className="text-xs font-bold text-amber-400 group-hover:translate-x-1 transition-transform flex items-center">
              Main Misi <ChevronRight className="w-4 h-4 ml-0.5" />
            </span>
          </div>
        </div>
      </div>

      {/* Footer Controls: Reset Game & Info */}
      <footer className="relative w-full max-w-5xl flex items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-900 z-10">
        <div className="flex items-center gap-1 text-slate-400">
          <Info className="w-3.5 h-3.5 text-sky-400" />
          <span>Berdasarkan DSKP KSSR Sains Tahun 5 Unit 9 (Fasa Bulan & Buruj).</span>
        </div>

        <button
          onClick={() => setShowResetConfirm(true)}
          type="button"
          className="flex items-center gap-1 text-rose-400/80 hover:text-rose-400 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Mulakan Semula Permainan</span>
        </button>
      </footer>

      {/* Instructions / Panduan Modal */}
      {showInstructions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-sky-400" />
                <h3 className="text-lg font-bold text-white">Panduan Permainan & DSKP Sains</h3>
              </div>
              <button
                onClick={() => setShowInstructions(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <h4 className="font-bold text-sky-300">1. Objektif Pembelajaran (DSKP Sains Tahun 5)</h4>
                <ul className="list-disc list-inside text-xs space-y-1 text-slate-300">
                  <li><strong>9.1 Fasa Bulan:</strong> Menyatakan Bulan tidak mengeluarkan cahaya tetapi memantulkan cahaya Matahari. Memerihalkan Bulan berputar pada paksinya dan beredar mengelilingi Bumi (27 1/3 hari, lawan arah jam). Menyusun fasa-fasa Bulan dalam Takwim Qamari.</li>
                  <li><strong>9.2 Buruj:</strong> Mengenal pasti maksud buruj, corak 4 buruj (Biduk, Belantik, Pari, Skorpio), serta kegunaannya sebagai petunjuk arah dan petunjuk musim.</li>
                </ul>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <h4 className="font-bold text-amber-300">2. Cara Bermain & Sistem Ganjaran</h4>
                <ul className="list-disc list-inside text-xs space-y-1 text-slate-300">
                  <li><strong>Misi Bulan:</strong> Kawal larian angkasawan di Bulan (Spacebar / Butang Lompat). Capai 7 checkpoint untuk menjawab soalan Fasa Bulan.</li>
                  <li><strong>Misi Bintang:</strong> Teroka 7 bintang bersinar di angkasa dan selesaikan cabaran buruj.</li>
                  <li><strong>Eksplorasi Angkasa:</strong> Ikuti peta perjalanan interaktif 7 zon kosmik untuk mengaktifkan teras galaksi.</li>
                  <li>Setiap jawapan betul memberikan markah. Anda boleh mencuba semula jika jawapan salah sehingga betul. Setiap misi yang selesai akan menganugerahkan 1 Bintang!</li>
                </ul>
              </div>
            </div>

            <button
              onClick={() => setShowInstructions(false)}
              className="w-full py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-sm cursor-pointer"
            >
              Faham, Mari Mula Bermain!
            </button>
          </div>
        </div>
      )}

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="w-full max-w-md bg-slate-900 border border-rose-500/40 rounded-2xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto">
              <RotateCcw className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Mulakan Semula Permainan?</h3>
            <p className="text-xs text-slate-300">
              Semua markah terkumpul dan kemajuan checkpoint akan diset semula ke sifar supaya murid baru boleh bermain.
            </p>
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                type="button"
                className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  soundEffects.playClick();
                  onResetGame();
                  setShowResetConfirm(false);
                }}
                type="button"
                className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer"
              >
                Ya, Set Semula
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
