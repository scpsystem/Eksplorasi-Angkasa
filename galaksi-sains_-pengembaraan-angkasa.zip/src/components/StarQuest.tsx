import React, { useState } from 'react';
import { GameProgress } from '../types/game';
import { STAR_QUEST_QUESTIONS } from '../data/learningContent';
import { CharacterAvatar } from './CharacterAvatars';
import { QuestionModal } from './QuestionModal';
import { ConstellationVisualizer } from './ConstellationIllustrations';
import { soundEffects } from '../utils/audio';
import { ArrowLeft, Star, Compass, Award, Telescope, Eye } from 'lucide-react';

interface StarQuestProps {
  progress: GameProgress;
  onUpdateScore: (newScore: number) => void;
  onCompleteMission: (mission: 'starQuest') => void;
  onBackToMenu: () => void;
}

export const StarQuest: React.FC<StarQuestProps> = ({
  progress,
  onUpdateScore,
  onCompleteMission,
  onBackToMenu
}) => {
  const [currentStarIdx, setCurrentStarIdx] = useState<number>(0);
  const [activeQuestion, setActiveQuestion] = useState<(typeof STAR_QUEST_QUESTIONS)[0] | null>(null);
  const [isMissionComplete, setIsMissionComplete] = useState<boolean>(false);
  const [selectedConstellationTab, setSelectedConstellationTab] = useState<'semua' | 'biduk' | 'belantik' | 'pari' | 'skorpio'>('semua');
  const [stardustCollected, setStardustCollected] = useState<number>(0);

  const totalStars = STAR_QUEST_QUESTIONS.length; // Exactly 7

  // Star Node data with unique space positions and themes
  const starNodes = [
    { id: 1, name: 'Bintang Al-Taer', constellationHint: 'Konsep Asas Buruj', x: 12, y: 35, color: '#38BDF8' },
    { id: 2, name: 'Bintang Megrez', constellationHint: '4 Corak Utama', x: 25, y: 70, color: '#818CF8' },
    { id: 3, name: 'Bintang Acrux', constellationHint: 'Buruj Pari (Paling Kecil)', x: 42, y: 25, color: '#22D3EE' },
    { id: 4, name: 'Bintang Merak', constellationHint: 'Buruj Biduk & 7 Bintang', x: 55, y: 65, color: '#A78BFA' },
    { id: 5, name: 'Bintang Polaris', constellationHint: 'Petunjuk Arah Kompas', x: 70, y: 30, color: '#F43F5E' },
    { id: 6, name: 'Bintang Antares', constellationHint: 'Petunjuk Musim Pertanian', x: 82, y: 72, color: '#F59E0B' },
    { id: 7, name: 'Bintang Betelgeuse', constellationHint: 'Hemisfera & Musim Sejuk', x: 92, y: 40, color: '#10B981' }
  ];

  // Navigate astronaut to star
  const handleStarClick = (idx: number) => {
    // Check if star is unlocked (must be current or previously completed)
    if (idx > currentStarIdx) {
      soundEffects.playWrong();
      return;
    }
    soundEffects.playThruster();
    setActiveQuestion(STAR_QUEST_QUESTIONS[idx]);
  };

  const handleCollectDust = () => {
    soundEffects.playCollect();
    setStardustCollected(prev => prev + 1);
    onUpdateScore(progress.totalScore + 10);
  };

  const handleQuestionSuccess = (pointsAwarded: number) => {
    onUpdateScore(progress.totalScore + pointsAwarded);
    setActiveQuestion(null);

    const nextIdx = currentStarIdx + 1;
    setCurrentStarIdx(nextIdx);

    if (nextIdx >= totalStars) {
      setIsMissionComplete(true);
      onCompleteMission('starQuest');
      soundEffects.playLevelUp();
    }
  };

  const currentPercent = Math.min(100, Math.round((currentStarIdx / totalStars) * 100));

  return (
    <div className="relative w-full min-h-[90vh] flex flex-col items-center bg-slate-950 text-white select-none">
      {/* Top HUD */}
      <div className="w-full max-w-5xl px-4 py-3 flex items-center justify-between border-b border-slate-800 bg-slate-900/80 backdrop-blur z-20">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundEffects.playClick();
              onBackToMenu();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-sky-300 border border-slate-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Menu Utama
          </button>
          <div className="hidden sm:block">
            <h2 className="text-sm font-bold text-white tracking-wide">Misi Bintang – Star Quest</h2>
            <span className="text-[11px] text-purple-400">Penerokaan Angkasa Lepas · Rahsia Buruj</span>
          </div>
        </div>

        {/* Center Progress Bar */}
        <div className="flex-1 max-w-xs mx-4">
          <div className="flex items-center justify-between text-[11px] mb-1 font-semibold">
            <span className="text-slate-300">Bintang Diteroka: {currentStarIdx} / {totalStars}</span>
            <span className="text-purple-300">{currentPercent}% Lengkap</span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-purple-500 to-sky-400 transition-all duration-300 rounded-full"
              style={{ width: `${currentPercent}%` }}
            />
          </div>
        </div>

        {/* Right Score */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs text-slate-400">Markah Terkumpul</div>
            <div className="text-base font-bold text-amber-300 tabular-nums">{progress.totalScore}</div>
          </div>
          <button
            onClick={handleCollectDust}
            type="button"
            className="flex items-center gap-1 bg-purple-950/70 hover:bg-purple-900/80 px-2.5 py-1 rounded-lg border border-purple-700 text-xs text-purple-300 font-bold active:scale-95 transition-all"
            title="Kumpul Debu Bintang Kosmik (+10 Markah)"
          >
            <Star className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
            <span>+{stardustCollected * 10} Stardust</span>
          </button>
        </div>
      </div>

      {/* Main Star Map Viewport */}
      <div className="relative w-full max-w-5xl flex-1 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#1E1B4B] via-[#090D16] to-[#020617] border-x border-slate-800 overflow-hidden min-h-[460px] flex flex-col justify-between">
        {/* Constellation Star Map Canvas */}
        <div className="relative w-full h-80 sm:h-96">
          {/* Animated SVG Sky & Celestial Hyperspace Waypoints */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {/* Connecting Stardust Path */}
            <polyline
              points={starNodes.map(s => `${s.x}%,${s.y}%`).join(' ')}
              fill="none"
              stroke="#6366F1"
              strokeWidth="2"
              strokeDasharray="6 4"
              opacity="0.4"
            />
            {/* Completed path highlight */}
            {currentStarIdx > 0 && (
              <polyline
                points={starNodes.slice(0, currentStarIdx + 1).map(s => `${s.x}%,${s.y}%`).join(' ')}
                fill="none"
                stroke="#38BDF8"
                strokeWidth="2.5"
                opacity="0.8"
              />
            )}
          </svg>

          {/* Interactive Star Nodes on Map */}
          {starNodes.map((star, idx) => {
            const isCompleted = idx < currentStarIdx;
            const isCurrent = idx === currentStarIdx;
            const isLocked = idx > currentStarIdx;

            return (
              <div
                key={star.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10 transition-all cursor-pointer group"
                style={{ left: `${star.x}%`, top: `${star.y}%` }}
                onClick={() => handleStarClick(idx)}
              >
                {/* Glowing Aura for Active Star */}
                {isCurrent && (
                  <div className="absolute inset-0 w-16 h-16 -left-3 -top-3 rounded-full bg-sky-400/20 animate-ping pointer-events-none" />
                )}

                <div
                  className={`relative w-10 h-10 rounded-full flex items-center justify-center border-2 transition-transform duration-300 group-hover:scale-125 ${
                    isCompleted
                      ? 'bg-emerald-950/80 border-emerald-400 text-emerald-300 shadow-[0_0_15px_#10b981]'
                      : isCurrent
                      ? 'bg-sky-950/90 border-sky-400 text-sky-200 shadow-[0_0_20px_#38bdf8] animate-bounce'
                      : 'bg-slate-900/80 border-slate-700 text-slate-500 opacity-60'
                  }`}
                >
                  {isCompleted ? (
                    <span className="font-bold text-xs">✓</span>
                  ) : isCurrent ? (
                    <Star className="w-5 h-5 fill-sky-400 text-sky-400" />
                  ) : (
                    <span className="font-mono text-xs font-bold">{idx + 1}</span>
                  )}
                </div>

                {/* Floating Tooltip Label */}
                <div className="absolute top-11 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-slate-900/90 border border-slate-700 px-2 py-0.5 rounded text-[10px] pointer-events-none z-20 shadow-lg">
                  <span className={`font-bold block ${isCurrent ? 'text-sky-300' : 'text-slate-300'}`}>
                    {star.name}
                  </span>
                  <span className="text-slate-400 text-[9px]">{star.constellationHint}</span>
                </div>
              </div>
            );
          })}

          {/* Floating Astronaut with Jetpack near Current Star */}
          {currentStarIdx < totalStars && (
            <div
              className="absolute z-20 transition-all duration-700 pointer-events-none"
              style={{
                left: `calc(${starNodes[currentStarIdx].x}% - 40px)`,
                top: `calc(${starNodes[currentStarIdx].y}% - 55px)`
              }}
            >
              <CharacterAvatar
                gender={progress.character}
                size={54}
                isAnimated={true}
                action="jumping"
              />
            </div>
          )}
        </div>

        {/* Interactive Constellation Observatory Panel at Bottom */}
        <div className="w-full bg-slate-900/95 border-t border-slate-800 p-4 z-20 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Telescope className="w-4 h-4 text-purple-400" />
              <h3 className="text-xs sm:text-sm font-bold text-white tracking-wide">
                Observatori Astronomi Buruj: Teropong 4 Corak Buruj
              </h3>
            </div>

            {/* Filter Tabs for the 4 Constellations */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
              {(['semua', 'biduk', 'belantik', 'pari', 'skorpio'] as const).map(tab => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => {
                    soundEffects.playClick();
                    setSelectedConstellationTab(tab);
                  }}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors capitalize ${
                    selectedConstellationTab === tab
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab === 'semua' ? 'Semua (4 Buruj)' : tab}
                </button>
              ))}
            </div>
          </div>

          {/* Render Constellation Visualizer Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 max-h-56 overflow-y-auto">
            {(selectedConstellationTab === 'semua' || selectedConstellationTab === 'biduk') && (
              <ConstellationVisualizer type="biduk" size="sm" />
            )}
            {(selectedConstellationTab === 'semua' || selectedConstellationTab === 'belantik') && (
              <ConstellationVisualizer type="belantik" size="sm" />
            )}
            {(selectedConstellationTab === 'semua' || selectedConstellationTab === 'pari') && (
              <ConstellationVisualizer type="pari" size="sm" />
            )}
            {(selectedConstellationTab === 'semua' || selectedConstellationTab === 'skorpio') && (
              <ConstellationVisualizer type="skorpio" size="sm" />
            )}
          </div>
        </div>
      </div>

      {/* Checkpoint Question Modal Pop-up */}
      {activeQuestion && (
        <QuestionModal
          question={activeQuestion}
          checkpointNumber={currentStarIdx + 1}
          totalCheckpoints={totalStars}
          onAnswerCorrect={handleQuestionSuccess}
        />
      )}

      {/* Mission Completion Modal */}
      {isMissionComplete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="w-full max-w-lg bg-slate-900 border-2 border-purple-500/60 rounded-2xl p-6 text-center space-y-5 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center mx-auto border border-purple-400/40">
              <Award className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-xs uppercase tracking-widest text-purple-400 font-bold">Misi Selesai!</span>
              <h3 className="text-2xl font-extrabold text-white">Misi Bintang Berjaya Diteroka!</h3>
              <p className="text-sm text-slate-300">
                Tahniah! Anda telah membongkar semua rahsia buruj: Biduk, Belantik, Pari, dan Skorpio serta fungsinya sebagai petunjuk arah dan musim.
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-around">
              <div>
                <span className="text-xs text-slate-400 block">Bintang Misi</span>
                <div className="flex items-center gap-1 text-amber-400 font-bold mt-1">
                  <Star className="w-5 h-5 fill-amber-400" />
                  <span>+1 Bintang</span>
                </div>
              </div>
              <div className="h-8 w-px bg-slate-800" />
              <div>
                <span className="text-xs text-slate-400 block">Bintang Selesai</span>
                <span className="text-base font-bold text-purple-400 mt-1 block">
                  7 / 7 Bintang
                </span>
              </div>
              <div className="h-8 w-px bg-slate-800" />
              <div>
                <span className="text-xs text-slate-400 block">Jumlah Markah</span>
                <span className="text-base font-bold text-amber-300 mt-1 block">
                  {progress.totalScore}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  soundEffects.playClick();
                  onBackToMenu();
                }}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm transition-all shadow-lg shadow-purple-600/30 cursor-pointer"
              >
                Kembali ke Menu Utama
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
