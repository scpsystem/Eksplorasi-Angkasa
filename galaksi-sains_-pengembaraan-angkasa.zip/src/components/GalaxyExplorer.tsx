import React, { useState } from 'react';
import { GameProgress } from '../types/game';
import { GALAXY_EXPLORER_CHECKPOINTS } from '../data/learningContent';
import { CharacterAvatar } from './CharacterAvatars';
import { QuestionModal } from './QuestionModal';
import { soundEffects } from '../utils/audio';
import { ArrowLeft, Rocket, Moon, Sparkles, Star, Award, Compass, Calendar, Lock, CheckCircle2 } from 'lucide-react';

interface GalaxyExplorerProps {
  progress: GameProgress;
  onUpdateScore: (newScore: number) => void;
  onCompleteMission: (mission: 'galaxyExplorer') => void;
  onBackToMenu: () => void;
}

export const GalaxyExplorer: React.FC<GalaxyExplorerProps> = ({
  progress,
  onUpdateScore,
  onCompleteMission,
  onBackToMenu
}) => {
  const [currentStepIdx, setCurrentStepIdx] = useState<number>(0);
  const [activeChallenge, setActiveChallenge] = useState<(typeof GALAXY_EXPLORER_CHECKPOINTS)[0] | null>(null);
  const [isGalaxyComplete, setIsGalaxyComplete] = useState<boolean>(false);

  const totalSteps = GALAXY_EXPLORER_CHECKPOINTS.length; // 7

  // 2D coordinates for the cosmic journey path on the galaxy map
  const mapCoordinates = [
    { x: 12, y: 78, type: 'stesen' },
    { x: 26, y: 55, type: 'bulan' },
    { x: 40, y: 32, type: 'bulan' },
    { x: 55, y: 52, type: 'buruj' },
    { x: 68, y: 28, type: 'buruj' },
    { x: 80, y: 62, type: 'buruj' },
    { x: 90, y: 35, type: 'teras' }
  ];

  const handleNodeClick = (idx: number) => {
    // Only allow active step or reviewed previous steps
    if (idx > currentStepIdx) {
      soundEffects.playWrong();
      return;
    }
    soundEffects.playThruster();
    setActiveChallenge(GALAXY_EXPLORER_CHECKPOINTS[idx]);
  };

  const handleChallengeSuccess = (pointsAwarded: number) => {
    onUpdateScore(progress.totalScore + pointsAwarded);
    setActiveChallenge(null);

    const nextIdx = currentStepIdx + 1;
    setCurrentStepIdx(nextIdx);

    if (nextIdx >= totalSteps) {
      setIsGalaxyComplete(true);
      onCompleteMission('galaxyExplorer');
      soundEffects.playLevelUp();
    } else {
      soundEffects.playCorrect();
    }
  };

  const currentPercent = Math.min(100, Math.round((currentStepIdx / totalSteps) * 100));

  return (
    <div className="relative w-full min-h-[90vh] flex flex-col items-center bg-slate-950 text-white select-none">
      {/* Top HUD */}
      <div className="w-full max-w-5xl px-4 py-3 flex items-center justify-between border-b border-slate-800 bg-slate-900/80 backdrop-blur z-20">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundEffects.playClick();
              onBackToMenu();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-sky-300 border border-slate-700 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" /> Menu Utama
          </button>
          <div className="hidden sm:block">
            <h2 className="text-sm font-bold text-white tracking-wide">Eksplorasi Angkasa – Galaxy Explorer</h2>
            <span className="text-[11px] text-amber-400">Peta Pengembaraan Galaksi · Fasa Bulan & Buruj</span>
          </div>
        </div>

        {/* Center Progress Bar */}
        <div className="flex-1 max-w-xs mx-4">
          <div className="flex items-center justify-between text-[11px] mb-1 font-semibold">
            <span className="text-slate-300">Zon Selesai: {currentStepIdx} / {totalSteps}</span>
            <span className="text-amber-300">{currentPercent}% Berjaya</span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-amber-400 transition-all duration-300 rounded-full"
              style={{ width: `${currentPercent}%` }}
            />
          </div>
        </div>

        {/* Right Score */}
        <div className="text-right">
          <div className="text-xs text-slate-400">Markah Terkumpul</div>
          <div className="text-base font-bold text-amber-300 tabular-nums">{progress.totalScore}</div>
        </div>
      </div>

      {/* Galaxy Map Canvas Container */}
      <div className="relative w-full max-w-5xl flex-1 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-950 via-[#0B0F19] to-[#030712] border-x border-slate-800 overflow-hidden min-h-[500px] flex flex-col justify-between p-4 sm:p-6">
        {/* Cosmic Background Nebulas & Spiral Center */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-60">
          <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full bg-purple-600/20 blur-3xl animate-pulse" />
          <div className="absolute top-1/2 -left-20 w-80 h-80 rounded-full bg-sky-600/15 blur-3xl" />
          <div className="absolute -bottom-20 right-1/3 w-96 h-96 rounded-full bg-amber-600/15 blur-3xl" />
        </div>

        {/* SVG Cosmic Journey Trails */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <defs>
            <linearGradient id="hyperspaceGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0284C7" />
              <stop offset="50%" stopColor="#818CF8" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
          </defs>

          {/* Full Galaxy Path Curve */}
          <path
            d="M 12% 78% Q 20% 65% 26% 55% T 40% 32% T 55% 52% T 68% 28% T 80% 62% T 90% 35%"
            fill="none"
            stroke="#334155"
            strokeWidth="4"
            strokeDasharray="8 6"
          />

          {/* Completed Path Glow */}
          {currentStepIdx > 0 && (
            <path
              d="M 12% 78% Q 20% 65% 26% 55% T 40% 32% T 55% 52% T 68% 28% T 80% 62% T 90% 35%"
              fill="none"
              stroke="url(#hyperspaceGrad)"
              strokeWidth="5"
              strokeLinecap="round"
              opacity="0.9"
            />
          )}
        </svg>

        {/* Interactive Checkpoint Nodes on Galaxy Map */}
        <div className="relative w-full h-[360px] sm:h-[400px]">
          {GALAXY_EXPLORER_CHECKPOINTS.map((checkpoint, idx) => {
            const coord = mapCoordinates[idx];
            const isCompleted = idx < currentStepIdx;
            const isCurrent = idx === currentStepIdx;
            const isLocked = idx > currentStepIdx;

            // Icon by topic type as required by user prompt
            let IconComponent = Rocket;
            let iconColor = 'text-sky-300';
            if (checkpoint.topicType === 'bulan') {
              IconComponent = Moon;
              iconColor = 'text-amber-300';
            } else if (checkpoint.topicType === 'buruj') {
              IconComponent = Compass;
              iconColor = 'text-purple-300';
            } else if (checkpoint.topicType === 'teras') {
              IconComponent = Sparkles;
              iconColor = 'text-rose-300';
            }

            return (
              <div
                key={checkpoint.step}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10 transition-all cursor-pointer group"
                style={{ left: `${coord.x}%`, top: `${coord.y}%` }}
                onClick={() => handleNodeClick(idx)}
              >
                {/* Active Pulsing Ring */}
                {isCurrent && (
                  <div className="absolute inset-0 w-16 h-16 -left-2 -top-2 rounded-full bg-amber-400/25 animate-ping pointer-events-none" />
                )}

                {/* Node Orb */}
                <div
                  className={`relative w-12 h-12 rounded-2xl flex items-center justify-center border-2 transition-transform duration-300 group-hover:scale-125 shadow-xl ${
                    isCompleted
                      ? 'bg-emerald-950 border-emerald-400 text-emerald-300 shadow-[0_0_15px_#10b981]'
                      : isCurrent
                      ? 'bg-amber-950 border-amber-400 text-amber-200 shadow-[0_0_25px_#f59e0b] animate-bounce ring-2 ring-amber-400/60'
                      : 'bg-slate-900 border-slate-800 text-slate-600 opacity-60'
                  }`}
                >
                  {isCompleted ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  ) : isLocked ? (
                    <Lock className="w-5 h-5 text-slate-500" />
                  ) : (
                    <IconComponent className={`w-6 h-6 ${iconColor}`} />
                  )}

                  {/* Step Badge */}
                  <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-slate-800 border border-slate-600 text-[10px] font-bold flex items-center justify-center text-white">
                    {checkpoint.step}
                  </span>
                </div>

                {/* Node Title Card */}
                <div
                  className={`absolute top-14 left-1/2 transform -translate-x-1/2 whitespace-nowrap px-2.5 py-1 rounded-lg border text-center transition-all z-20 shadow-md ${
                    isCurrent
                      ? 'bg-amber-950/95 border-amber-400 text-amber-200 ring-1 ring-amber-400 scale-105'
                      : isCompleted
                      ? 'bg-slate-900/90 border-emerald-500/50 text-emerald-300'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className="text-xs font-bold block">{checkpoint.name}</span>
                  <span className="text-[10px] text-slate-300 block">{checkpoint.subtitle}</span>
                </div>
              </div>
            );
          })}

          {/* Player Spaceship / Character Position Indicator */}
          {currentStepIdx < totalSteps && (
            <div
              className="absolute z-30 transition-all duration-700 pointer-events-none"
              style={{
                left: `calc(${mapCoordinates[currentStepIdx].x}% - 40px)`,
                top: `calc(${mapCoordinates[currentStepIdx].y}% - 65px)`
              }}
            >
              <CharacterAvatar
                gender={progress.character}
                size={54}
                isAnimated={true}
                action="celebrate"
              />
            </div>
          )}
        </div>

        {/* Bottom Route Legend & Current Mission Guidance */}
        <div className="w-full bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 z-20 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 border border-sky-400/30">
              <Rocket className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-sky-400 font-semibold uppercase tracking-wider block">
                Zon Semasa ({currentStepIdx + 1} / {totalSteps}):
              </span>
              <h4 className="text-sm font-bold text-white">
                {currentStepIdx < totalSteps
                  ? GALAXY_EXPLORER_CHECKPOINTS[currentStepIdx].challengeTitle
                  : 'Teras Galaksi Berjaya Diaktifkan!'}
              </h4>
              <p className="text-xs text-slate-400">
                {currentStepIdx < totalSteps
                  ? GALAXY_EXPLORER_CHECKPOINTS[currentStepIdx].description
                  : 'Semua checkpoint berjaya dilengkapkan!'}
              </p>
            </div>
          </div>

          {currentStepIdx < totalSteps && (
            <button
              onClick={() => handleNodeClick(currentStepIdx)}
              type="button"
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/25 active:scale-95 cursor-pointer shrink-0"
            >
              Mulakan Cabaran Zon Ini
            </button>
          )}
        </div>
      </div>

      {/* Checkpoint Challenge Question Modal */}
      {activeChallenge && (
        <QuestionModal
          question={{
            id: activeChallenge.step,
            title: `${activeChallenge.name}: ${activeChallenge.challengeTitle}`,
            topic: 'gabungan',
            standardLearning: activeChallenge.standardLearning,
            questionText: activeChallenge.questionText,
            type: activeChallenge.type,
            options: activeChallenge.options,
            correctOptionId: activeChallenge.correctOptionId,
            sequenceItems: activeChallenge.sequenceItems,
            correctSequenceIds: activeChallenge.correctSequenceIds,
            matchPairs: activeChallenge.matchPairs,
            explanation: activeChallenge.explanation,
            factSource: 'DSKP KSSR Sains Tahun 5 Unit 9',
            points: activeChallenge.points
          }}
          checkpointNumber={activeChallenge.step}
          totalCheckpoints={totalSteps}
          onAnswerCorrect={handleChallengeSuccess}
        />
      )}

      {/* Galaxy Victory Modal */}
      {isGalaxyComplete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="w-full max-w-lg bg-slate-900 border-2 border-amber-500/60 rounded-2xl p-6 text-center space-y-5 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-400/40">
              <Award className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-xs uppercase tracking-widest text-amber-400 font-bold">Galaksi Berjaya Diteroka!</span>
              <h3 className="text-2xl font-extrabold text-white">Teras Galaksi Berjaya Diaktifkan!</h3>
              <p className="text-sm text-slate-300">
                Syabas dan tahniah! Anda telah membuktikan penguasaan ilmu Sains yang cemerlang mengenai Fasa Bulan dan Buruj merentasi seluruh Galaksi Sains!
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-around">
              <div>
                <span className="text-xs text-slate-400 block">Bintang Misi</span>
                <div className="flex items-center gap-1 text-amber-400 font-bold mt-1">
                  <Star className="w-5 h-5 fill-amber-400" />
                  <span>+1 Bintang</span>
                </div>
              </div>
              <div className="h-8 w-px bg-slate-800" />
              <div>
                <span className="text-xs text-slate-400 block">Status Perjalanan</span>
                <span className="text-base font-bold text-emerald-400 mt-1 block">
                  100% Selesai
                </span>
              </div>
              <div className="h-8 w-px bg-slate-800" />
              <div>
                <span className="text-xs text-slate-400 block">Jumlah Markah</span>
                <span className="text-base font-bold text-amber-300 mt-1 block">
                  {progress.totalScore}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  soundEffects.playClick();
                  onBackToMenu();
                }}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-all shadow-lg shadow-amber-500/30 cursor-pointer"
              >
                Kembali ke Menu Utama
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
