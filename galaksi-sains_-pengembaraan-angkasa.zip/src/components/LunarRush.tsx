import React, { useState, useEffect, useRef, useCallback } from 'react';
import { CharacterGender, GameProgress } from '../types/game';
import { LUNAR_RUSH_QUESTIONS } from '../data/learningContent';
import { CharacterAvatar } from './CharacterAvatars';
import { QuestionModal } from './QuestionModal';
import { soundEffects } from '../utils/audio';
import { Play, Pause, RotateCcw, ArrowLeft, Star, Sparkles, Volume2, VolumeX, Shield, Award } from 'lucide-react';

interface LunarRushProps {
  progress: GameProgress;
  onUpdateScore: (newScore: number) => void;
  onCompleteMission: (mission: 'lunarRush') => void;
  onBackToMenu: () => void;
}

interface Obstacle {
  id: number;
  x: number;
  type: 'rock' | 'crater' | 'debris';
  width: number;
  height: number;
}

interface Collectible {
  id: number;
  x: number;
  y: number;
  collected: boolean;
}

export const LunarRush: React.FC<LunarRushProps> = ({
  progress,
  onUpdateScore,
  onCompleteMission,
  onBackToMenu
}) => {
  // Game running state
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentCheckpointIdx, setCurrentCheckpointIdx] = useState<number>(0);
  const [activeQuestion, setActiveQuestion] = useState<(typeof LUNAR_RUSH_QUESTIONS)[0] | null>(null);
  const [isMissionComplete, setIsMissionComplete] = useState<boolean>(false);

  // Astronaut Runner State
  const [astronautY, setAstronautY] = useState<number>(0); // 0 is ground
  const [isJumping, setIsJumping] = useState<boolean>(false);
  const [isDucking, setIsDucking] = useState<boolean>(false);
  const [distance, setDistance] = useState<number>(0);
  const [moonCrystalsCollected, setMoonCrystalsCollected] = useState<number>(0);

  // Checkpoint thresholds in meters/distance units
  const CHECKPOINT_DISTANCE = 500; // Each checkpoint every 500 distance units
  const targetCheckpoints = LUNAR_RUSH_QUESTIONS.length; // Exactly 7

  // Obstacles and collectibles pool
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const [collectibles, setCollectibles] = useState<Collectible[]>([]);

  // Canvas / Animation refs
  const requestRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());
  const groundY = 280; // pixel level

  // Trigger jump
  const handleJump = useCallback(() => {
    if (isJumping || !isPlaying || activeQuestion) return;
    soundEffects.playJump();
    setIsJumping(true);
    let jumpVelocity = 14;
    let currentY = 0;

    const jumpInterval = setInterval(() => {
      currentY += jumpVelocity;
      jumpVelocity -= 0.8; // gravity

      if (currentY <= 0) {
        currentY = 0;
        setIsJumping(false);
        setAstronautY(0);
        clearInterval(jumpInterval);
      } else {
        setAstronautY(currentY);
      }
    }, 20);
  }, [isJumping, isPlaying, activeQuestion]);

  // Trigger duck / slide
  const handleDuck = useCallback(() => {
    if (isJumping || !isPlaying || activeQuestion) return;
    setIsDucking(true);
    setTimeout(() => {
      setIsDucking(false);
    }, 600);
  }, [isJumping, isPlaying, activeQuestion]);

  // Keyboard controls listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeQuestion) return;
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.key === 'w') {
        e.preventDefault();
        handleJump();
      } else if (e.code === 'ArrowDown' || e.key === 's') {
        e.preventDefault();
        handleDuck();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleJump, handleDuck, activeQuestion]);

  // Main runner loop
  useEffect(() => {
    if (!isPlaying || activeQuestion || isMissionComplete) return;

    let obstacleTimer = 0;
    let collectibleTimer = 0;

    const gameLoop = (time: number) => {
      const delta = (time - lastTimeRef.current) / 1000;
      lastTimeRef.current = time;

      // Increase distance
      setDistance(prev => {
        const nextDist = prev + 120 * delta;

        // Check if reached next checkpoint
        const currentTargetDist = (currentCheckpointIdx + 1) * CHECKPOINT_DISTANCE;
        if (nextDist >= currentTargetDist && currentCheckpointIdx < targetCheckpoints) {
          // Pause game and trigger question modal
          soundEffects.playLevelUp();
          setActiveQuestion(LUNAR_RUSH_QUESTIONS[currentCheckpointIdx]);
          return currentTargetDist;
        }

        return nextDist;
      });

      // Spawn obstacles occasionally
      obstacleTimer += delta;
      if (obstacleTimer > 2.8) {
        obstacleTimer = 0;
        setObstacles(prev => [
          ...prev,
          {
            id: Date.now(),
            x: 850,
            type: Math.random() > 0.5 ? 'crater' : 'rock',
            width: 40,
            height: 35
          }
        ]);
      }

      // Spawn collectible moon crystals
      collectibleTimer += delta;
      if (collectibleTimer > 1.6) {
        collectibleTimer = 0;
        setCollectibles(prev => [
          ...prev,
          {
            id: Date.now(),
            x: 850,
            y: Math.random() > 0.5 ? 40 : 100, // low or high jump crystal
            collected: false
          }
        ]);
      }

      // Move obstacles & collision check
      setObstacles(prev =>
        prev
          .map(obs => ({ ...obs, x: obs.x - 240 * delta }))
          .filter(obs => obs.x > -80)
      );

      // Move collectibles & collect detection
      setCollectibles(prev =>
        prev
          .map(item => {
            const nextX = item.x - 240 * delta;
            // Astronaut is at X = 120
            const inRangeX = nextX > 90 && nextX < 150;
            const inRangeY = Math.abs(astronautY - item.y) < 45;

            if (inRangeX && inRangeY && !item.collected) {
              soundEffects.playCollect();
              setMoonCrystalsCollected(c => c + 1);
              onUpdateScore(progress.totalScore + 10);
              return { ...item, x: nextX, collected: true };
            }
            return { ...item, x: nextX };
          })
          .filter(item => item.x > -60 && !item.collected)
      );

      requestRef.current = requestAnimationFrame(gameLoop);
    };

    lastTimeRef.current = performance.now();
    requestRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [
    isPlaying,
    activeQuestion,
    currentCheckpointIdx,
    targetCheckpoints,
    astronautY,
    progress.totalScore,
    isMissionComplete,
    onUpdateScore
  ]);

  // When question is answered correctly
  const handleQuestionSuccess = (pointsAwarded: number) => {
    onUpdateScore(progress.totalScore + pointsAwarded);
    setActiveQuestion(null);

    const nextIdx = currentCheckpointIdx + 1;
    setCurrentCheckpointIdx(nextIdx);

    if (nextIdx >= targetCheckpoints) {
      // Completed all 7 checkpoints!
      setIsMissionComplete(true);
      onCompleteMission('lunarRush');
      soundEffects.playLevelUp();
    } else {
      setIsPlaying(true);
    }
  };

  const currentPercent = Math.min(100, Math.round((currentCheckpointIdx / targetCheckpoints) * 100));

  return (
    <div className="relative w-full min-h-[90vh] flex flex-col items-center bg-slate-950 text-white select-none">
      {/* Top HUD */}
      <div className="w-full max-w-5xl px-4 py-3 flex items-center justify-between border-b border-slate-800 bg-slate-900/80 backdrop-blur z-20">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundEffects.playClick();
              onBackToMenu();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-sky-300 border border-slate-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Menu Utama
          </button>
          <div className="hidden sm:block">
            <h2 className="text-sm font-bold text-white tracking-wide">Misi Bulan – Lunar Rush</h2>
            <span className="text-[11px] text-sky-400">Permukaan Bulan · Graviti Rendah</span>
          </div>
        </div>

        {/* Center Progress Bar */}
        <div className="flex-1 max-w-xs mx-4">
          <div className="flex items-center justify-between text-[11px] mb-1 font-semibold">
            <span className="text-slate-300">Checkpoint: {currentCheckpointIdx} / {targetCheckpoints}</span>
            <span className="text-amber-400">{currentPercent}% Lengkap</span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-sky-500 to-emerald-400 transition-all duration-300 rounded-full"
              style={{ width: `${currentPercent}%` }}
            />
          </div>
        </div>

        {/* Right Stats & Sound */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs text-slate-400">Markah Terkumpul</div>
            <div className="text-base font-bold text-amber-300 tabular-nums">{progress.totalScore}</div>
          </div>
          <div className="flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700 text-xs text-sky-300 font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{moonCrystalsCollected} Kristal</span>
          </div>
        </div>
      </div>

      {/* Main 2D Moon Canvas / Play Area */}
      <div className="relative w-full max-w-5xl flex-1 overflow-hidden bg-gradient-to-b from-slate-950 via-[#0B132B] to-[#1C2541] border-x border-slate-800 shadow-2xl min-h-[460px] flex flex-col justify-end">
        {/* Background Stars & Earth View */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Earth floating in the lunar sky */}
          <div className="absolute top-8 right-16 w-20 h-20 rounded-full bg-sky-600 shadow-[0_0_35px_rgba(56,189,248,0.4)] border border-sky-400/50 flex items-center justify-center opacity-90 overflow-hidden">
            <div className="w-full h-full bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-emerald-400 via-sky-600 to-indigo-950 opacity-90"></div>
            <span className="absolute text-[9px] font-bold text-white tracking-widest drop-shadow uppercase opacity-75">BUMI</span>
          </div>

          {/* Distant moon mountains parallax */}
          <svg className="absolute bottom-28 w-full h-32 opacity-40" viewBox="0 0 1000 120" preserveAspectRatio="none">
            <path d="M0,80 Q200,20 400,90 T800,40 T1200,90 L1200,120 L0,120 Z" fill="#1E293B" />
          </svg>
          <svg className="absolute bottom-24 w-full h-24 opacity-60" viewBox="0 0 1000 100" preserveAspectRatio="none">
            <path d="M0,60 Q300,10 600,70 T1000,50 L1000,100 L0,100 Z" fill="#0F172A" />
          </svg>
        </div>

        {/* Moon Surface Ground */}
        <div className="absolute bottom-0 w-full h-28 bg-[#334155] border-t-4 border-slate-500/80 z-10 overflow-hidden">
          {/* Surface Craters Texture */}
          <div className="absolute top-3 left-10 w-16 h-6 rounded-full bg-slate-700/80 border-b border-slate-600"></div>
          <div className="absolute top-10 left-64 w-24 h-8 rounded-full bg-slate-700/80 border-b border-slate-600"></div>
          <div className="absolute top-4 left-[500px] w-20 h-7 rounded-full bg-slate-700/80 border-b border-slate-600"></div>
          <div className="absolute top-12 left-[780px] w-14 h-5 rounded-full bg-slate-700/80 border-b border-slate-600"></div>

          {/* Lunar Dust Track Line */}
          <div className="w-full h-1 bg-slate-600/50 mt-2"></div>
        </div>

        {/* Checkpoint Station Flag / Pod marker ahead */}
        <div
          className="absolute z-10 transition-transform duration-100"
          style={{
            bottom: '108px',
            right: `${Math.max(10, 800 - (distance % CHECKPOINT_DISTANCE) * 1.5)}px`
          }}
        >
          <div className="flex flex-col items-center">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-500 text-slate-950 shadow-md">
              CP {currentCheckpointIdx + 1}
            </span>
            <div className="w-1.5 h-16 bg-sky-400"></div>
            <div className="w-12 h-8 rounded-t-xl bg-slate-800 border border-sky-400 flex items-center justify-center text-xs font-bold text-sky-300">
              POD
            </div>
          </div>
        </div>

        {/* Obstacles Rendering */}
        {obstacles.map(obs => (
          <div
            key={obs.id}
            className="absolute z-10 transition-transform pointer-events-none"
            style={{
              bottom: '108px',
              left: `${obs.x}px`,
              width: `${obs.width}px`,
              height: `${obs.height}px`
            }}
          >
            {obs.type === 'rock' ? (
              <svg viewBox="0 0 40 35" className="w-full h-full drop-shadow">
                <polygon points="10,35 0,20 15,5 30,0 40,15 35,35" fill="#64748B" stroke="#94A3B8" strokeWidth="1.5" />
                <polygon points="12,30 5,20 18,10 28,8 35,18 30,30" fill="#475569" />
              </svg>
            ) : (
              <div className="w-full h-4 bg-slate-900 rounded-full border-2 border-dashed border-red-400/80 flex items-center justify-center">
                <span className="text-[8px] text-red-300 font-bold uppercase">Kawah</span>
              </div>
            )}
          </div>
        ))}

        {/* Collectibles (Moon Crystals) */}
        {collectibles.map(item => (
          <div
            key={item.id}
            className="absolute z-10 transition-transform pointer-events-none animate-pulse"
            style={{
              bottom: `${115 + item.y}px`,
              left: `${item.x}px`
            }}
          >
            <div className="w-7 h-7 rounded-lg bg-sky-400 rotate-45 flex items-center justify-center shadow-[0_0_15px_#38bdf8] border border-white">
              <Sparkles className="w-4 h-4 text-white -rotate-45" />
            </div>
          </div>
        ))}

        {/* The Running Astronaut Character */}
        <div
          className="absolute z-20 transition-all duration-75"
          style={{
            bottom: `${110 + astronautY}px`,
            left: '120px',
            transform: isDucking ? 'scaleY(0.7) translateY(15px)' : 'none'
          }}
        >
          <CharacterAvatar
            gender={progress.character}
            size={76}
            isAnimated={true}
            action={isJumping ? 'jumping' : isDucking ? 'idle' : 'running'}
          />
          {/* Shadow beneath character on moon ground */}
          <div
            className="w-12 h-3 bg-black/40 rounded-full mx-auto blur-xs mt-1"
            style={{
              opacity: Math.max(0.2, 1 - astronautY / 150),
              transform: `scale(${Math.max(0.4, 1 - astronautY / 200)})`
            }}
          />
        </div>

        {/* On-Screen Touch / Action Controls for Mobile & Computer */}
        <div className="w-full p-4 z-20 flex items-center justify-between bg-slate-950/70 border-t border-slate-800/80 backdrop-blur-xs">
          <div className="text-xs text-slate-400 hidden sm:block">
            Gunakan <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-sky-300 font-mono">Space</kbd> / <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-sky-300 font-mono">▲</kbd> untuk melompat & <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-sky-300 font-mono">▼</kbd> untuk menunduk.
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-center">
            <button
              onClick={handleDuck}
              type="button"
              className="flex-1 sm:flex-none px-6 py-3 rounded-xl bg-slate-800 active:bg-slate-700 border border-slate-700 text-sm font-bold text-sky-200 shadow-md active:scale-95 transition-transform flex items-center justify-center gap-1.5"
            >
              <span>▼ Tunduk / Gelongsor</span>
            </button>
            <button
              onClick={handleJump}
              type="button"
              className="flex-1 sm:flex-none px-8 py-3 rounded-xl bg-sky-500 active:bg-sky-400 text-slate-950 text-sm font-extrabold shadow-lg shadow-sky-500/30 active:scale-95 transition-transform flex items-center justify-center gap-1.5"
            >
              <span>▲ LOMPAT</span>
            </button>
          </div>
        </div>
      </div>

      {/* Checkpoint Question Modal Pop-up */}
      {activeQuestion && (
        <QuestionModal
          question={activeQuestion}
          checkpointNumber={currentCheckpointIdx + 1}
          totalCheckpoints={targetCheckpoints}
          onAnswerCorrect={handleQuestionSuccess}
        />
      )}

      {/* Mission Completion Modal */}
      {isMissionComplete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="w-full max-w-lg bg-slate-900 border-2 border-emerald-500/60 rounded-2xl p-6 text-center space-y-5 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-400/40">
              <Award className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-xs uppercase tracking-widest text-emerald-400 font-bold">Misi Selesai!</span>
              <h3 className="text-2xl font-extrabold text-white">Misi Bulan Berjaya Ditawan!</h3>
              <p className="text-sm text-slate-300">
                Tahniah! Anda telah berjaya menyelesaikan semua 7 checkpoint Fasa Bulan dengan pemahaman saintifik yang mantap.
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-around">
              <div>
                <span className="text-xs text-slate-400 block">Bintang Misi</span>
                <div className="flex items-center gap-1 text-amber-400 font-bold mt-1">
                  <Star className="w-5 h-5 fill-amber-400" />
                  <span>+1 Bintang</span>
                </div>
              </div>
              <div className="h-8 w-px bg-slate-800" />
              <div>
                <span className="text-xs text-slate-400 block">Kristal Terkumpul</span>
                <span className="text-base font-bold text-sky-400 mt-1 block">
                  {moonCrystalsCollected} Kristal
                </span>
              </div>
              <div className="h-8 w-px bg-slate-800" />
              <div>
                <span className="text-xs text-slate-400 block">Jumlah Markah</span>
                <span className="text-base font-bold text-amber-300 mt-1 block">
                  {progress.totalScore}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  soundEffects.playClick();
                  onBackToMenu();
                }}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all shadow-lg shadow-emerald-500/30"
              >
                Kembali ke Menu Utama
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
