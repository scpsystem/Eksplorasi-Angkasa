export type CharacterGender = 'lelaki' | 'perempuan';

export interface CharacterProfile {
  id: CharacterGender;
  name: string;
  title: string;
  description: string;
  color: string;
}

export type GameActivity = 'menu' | 'lunar_rush' | 'star_quest' | 'galaxy_explorer';

export type QuestionType =
  | 'multiple_choice'
  | 'order_sequence'
  | 'match_pairs'
  | 'diagram_click'
  | 'fill_blank';

export interface QuestionOption {
  id: string;
  text: string;
  isCorrect?: boolean;
}

export interface CheckpointQuestion {
  id: number;
  title: string;
  topic: 'fasa_bulan' | 'buruj' | 'gabungan';
  standardLearning: string; // e.g. "SP 9.1.1", "SP 9.2.2"
  questionText: string;
  type: QuestionType;
  options?: QuestionOption[];
  correctOptionId?: string; // for multiple choice
  sequenceItems?: { id: string; name: string; visualType?: string }[]; // for order_sequence
  correctSequenceIds?: string[];
  matchPairs?: { left: string; right: string; leftId: string; rightId: string }[]; // for match_pairs
  blankSentence?: {
    before: string;
    after: string;
    options: string[];
    correctAnswer: string;
  };
  diagramType?: 'moon_phases' | 'moon_orbit' | 'constellations' | 'seasons';
  explanation: string;
  factSource: string; // Reference to textbook page
  points: number;
}

export interface GameProgress {
  totalScore: number;
  starsEarned: {
    lunarRush: boolean;
    starQuest: boolean;
    galaxyExplorer: boolean;
  };
  character: CharacterGender;
  lunarRushCompletedCheckpoints: number[];
  starQuestCompletedCheckpoints: number[];
  galaxyExplorerCompletedCheckpoints: number[];
  audioEnabled: boolean;
}
