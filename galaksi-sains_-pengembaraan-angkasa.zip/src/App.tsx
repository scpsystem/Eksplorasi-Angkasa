import React, { useState, useEffect } from 'react';
import { GameActivity, CharacterGender, GameProgress } from './types/game';
import { MainMenu } from './components/MainMenu';
import { LunarRush } from './components/LunarRush';
import { StarQuest } from './components/StarQuest';
import { GalaxyExplorer } from './components/GalaxyExplorer';
import { soundEffects } from './utils/audio';

const STORAGE_KEY = 'galaksi_sains_kssr_progress_v1';

const INITIAL_PROGRESS: GameProgress = {
  totalScore: 0,
  starsEarned: {
    lunarRush: false,
    starQuest: false,
    galaxyExplorer: false
  },
  character: 'lelaki',
  lunarRushCompletedCheckpoints: [],
  starQuestCompletedCheckpoints: [],
  galaxyExplorerCompletedCheckpoints: [],
  audioEnabled: true
};

export default function App() {
  const [currentActivity, setCurrentActivity] = useState<GameActivity>('menu');

  // Load progress from localStorage or default
  const [progress, setProgress] = useState<GameProgress>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return INITIAL_PROGRESS;
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch {
      // Ignore storage errors
    }
  }, [progress]);

  // Sync audio enabled state with sound manager
  useEffect(() => {
    soundEffects.isMuted = !progress.audioEnabled;
  }, [progress.audioEnabled]);

  const handleUpdateScore = (newScore: number) => {
    setProgress(prev => ({
      ...prev,
      totalScore: Math.max(prev.totalScore, newScore)
    }));
  };

  const handleCompleteMission = (mission: 'lunarRush' | 'starQuest' | 'galaxyExplorer') => {
    setProgress(prev => ({
      ...prev,
      starsEarned: {
        ...prev.starsEarned,
        [mission]: true
      }
    }));
  };

  const handleSelectCharacter = (character: CharacterGender) => {
    setProgress(prev => ({
      ...prev,
      character
    }));
  };

  const handleToggleAudio = () => {
    setProgress(prev => ({
      ...prev,
      audioEnabled: !prev.audioEnabled
    }));
  };

  const handleResetGame = () => {
    setProgress(INITIAL_PROGRESS);
    setCurrentActivity('menu');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-slate-950">
      {currentActivity === 'menu' && (
        <MainMenu
          progress={progress}
          onSelectCharacter={handleSelectCharacter}
          onStartActivity={act => setCurrentActivity(act)}
          onResetGame={handleResetGame}
          onToggleAudio={handleToggleAudio}
        />
      )}

      {currentActivity === 'lunar_rush' && (
        <LunarRush
          progress={progress}
          onUpdateScore={handleUpdateScore}
          onCompleteMission={handleCompleteMission}
          onBackToMenu={() => setCurrentActivity('menu')}
        />
      )}

      {currentActivity === 'star_quest' && (
        <StarQuest
          progress={progress}
          onUpdateScore={handleUpdateScore}
          onCompleteMission={handleCompleteMission}
          onBackToMenu={() => setCurrentActivity('menu')}
        />
      )}

      {currentActivity === 'galaxy_explorer' && (
        <GalaxyExplorer
          progress={progress}
          onUpdateScore={handleUpdateScore}
          onCompleteMission={handleCompleteMission}
          onBackToMenu={() => setCurrentActivity('menu')}
        />
      )}
    </div>
  );
}
